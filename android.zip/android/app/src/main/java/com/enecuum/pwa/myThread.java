package com.enecuum.pwa;

import static java.lang.Thread.*;

import com.getcapacitor.util.HostMask;

public class myThread extends Thread{
    private Thread t;
    public String threadName;
    private Miner[] miners;
    private boolean work = true;
    myThread(Miner[] miners){
        this.miners = miners;
    }

    public void run(){
        for(Miner miner:miners){
            miner.start();
        }
        System.out.println("thread alive: " + t.isAlive());
        while (!interrupted()){

        }
        System.out.println("interputed");
    }
    public void start(){
        this.t = new Thread(this);
        this.t.setDaemon(false);
        this.t.start();
    }

    public void Stop(){
        System.out.println("Thread is dead, " + this.t.isAlive());
        this.t.interrupt();
        System.out.println("Thread is dead, " + this.t.isAlive());

    }
}
