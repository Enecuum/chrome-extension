package com.enecuum.pwa;

import java.net.URI;
import com.enecuum.pwa.WS.*;

public class Publisher{

    public String url;
    private String key;
    public String token;
    public WS ws;
    

    Publisher(String url, String key, String token){
        this.url = url;
        this.key = key;
        this.token = token;
    }

    public void init(){
        System.out.println("miner is work "+this.key);
    }


}
