package com.enecuum.pwa;

import android.content.Context;
import android.content.Intent;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;


@CapacitorPlugin(name = "PoA")
public class PoA extends Plugin{

//    public Thread thread;
    public Miner[] miners;
    public Intent PoAIntent;


    @PluginMethod()
    public void start(PluginCall call) {
        JSObject obj = new JSObject();
        obj.put("status",call.getArray("value"));
        miners = new Miner[1];
        miners[0] = new Miner("123", "456", "789");
        if(this.PoAIntent == null){
            this.PoAIntent = new Intent(getActivity(), PoAService.class);
            getActivity().startService(PoAIntent);
        }
        call.resolve(obj);
    }

    @PluginMethod()
    public void stop(PluginCall call){
        getActivity().stopService(PoAIntent);
        PoAIntent = null;
        call.resolve();
    }

}
