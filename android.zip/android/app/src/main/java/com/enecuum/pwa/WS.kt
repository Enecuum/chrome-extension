package com.enecuum.pwa

import io.ktor.client.*
import io.ktor.client.plugins.websocket.*
import io.ktor.http.*
import io.ktor.websocket.*
import io.ktor.util.*

class WS (val url:String, val key:String, val token:String ){

}