package com.enecuum.pwa;

import android.app.Service;
import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.IBinder;

public class PoAService extends Service {

    private Miner[] miners;


//    PoAService(Miner[] miners){this.miners = miners;}


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
//        miners = new Miner[1];
//        miners[0] = new Miner("123", "456", "789");

        try{
            for(Miner miner:this.miners){
                miner.start();
            }
        }catch (Exception e){}

        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        System.out.println("Destroyed");
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
