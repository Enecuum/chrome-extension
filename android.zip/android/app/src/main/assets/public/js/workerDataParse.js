/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!**************************************!*\
  !*** ./src/utils/workerDataParse.js ***!
  \**************************************/
var document = '';
var window = '';
importScripts('/lib/enqweb3lib.ext.min.js');

onmessage = function onmessage(msg) {
  var data = ENQWeb.Utils.ofd.parse(msg.data);
  postMessage(JSON.stringify({
    parsed: true
  }));
};
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianMvd29ya2VyRGF0YVBhcnNlLmpzIiwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsSUFBSUEsUUFBUSxHQUFHLEVBQWY7QUFDQSxJQUFJQyxNQUFNLEdBQUcsRUFBYjtBQUNBQyxhQUFhLENBQUMsNEJBQUQsQ0FBYjs7QUFFQUMsU0FBUyxHQUFHLG1CQUFDQyxHQUFELEVBQVM7QUFDakIsTUFBSUMsSUFBSSxHQUFHQyxNQUFNLENBQUNDLEtBQVAsQ0FBYUMsR0FBYixDQUFpQkMsS0FBakIsQ0FBdUJMLEdBQUcsQ0FBQ0MsSUFBM0IsQ0FBWDtBQUNBSyxFQUFBQSxXQUFXLENBQUNDLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQUNDLElBQUFBLE1BQU0sRUFBRTtBQUFULEdBQWYsQ0FBRCxDQUFYO0FBQ0gsQ0FIRCxDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZW5lY3V1bS13YWxsZXQtZXh0ZW5zaW9uLy4vc3JjL3V0aWxzL3dvcmtlckRhdGFQYXJzZS5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJsZXQgZG9jdW1lbnQgPSAnJ1xubGV0IHdpbmRvdyA9ICcnXG5pbXBvcnRTY3JpcHRzKCcvbGliL2VucXdlYjNsaWIuZXh0Lm1pbi5qcycpXG5cbm9ubWVzc2FnZSA9IChtc2cpID0+IHtcbiAgICBsZXQgZGF0YSA9IEVOUVdlYi5VdGlscy5vZmQucGFyc2UobXNnLmRhdGEpXG4gICAgcG9zdE1lc3NhZ2UoSlNPTi5zdHJpbmdpZnkoe3BhcnNlZDogdHJ1ZX0pKVxufSJdLCJuYW1lcyI6WyJkb2N1bWVudCIsIndpbmRvdyIsImltcG9ydFNjcmlwdHMiLCJvbm1lc3NhZ2UiLCJtc2ciLCJkYXRhIiwiRU5RV2ViIiwiVXRpbHMiLCJvZmQiLCJwYXJzZSIsInBvc3RNZXNzYWdlIiwiSlNPTiIsInN0cmluZ2lmeSIsInBhcnNlZCJdLCJzb3VyY2VSb290IjoiIn0=