/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/utils/eventBus.js":
/*!*******************************!*\
  !*** ./src/utils/eventBus.js ***!
  \*******************************/
/***/ ((module) => {

var eventBus = {
  on: function on(event, callback) {
    document.addEventListener(event, function (e) {
      return callback(e.detail);
    });
  },
  dispatch: function dispatch(event, data) {
    document.dispatchEvent(new CustomEvent(event, {
      detail: data
    }));
  },
  remove: function remove(event, callback) {
    document.removeEventListener(event, callback);
  }
};
module.exports = eventBus;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!****************************!*\
  !*** ./src/lockAccount.js ***!
  \****************************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "decryptAccount": () => (/* binding */ decryptAccount),
/* harmony export */   "encryptAccount": () => (/* binding */ encryptAccount),
/* harmony export */   "encryptAccountWithPass": () => (/* binding */ encryptAccountWithPass),
/* harmony export */   "lockAccount": () => (/* binding */ lockAccount),
/* harmony export */   "lockTime": () => (/* binding */ lockTime),
/* harmony export */   "say": () => (/* binding */ say)
/* harmony export */ });
/* harmony import */ var _utils_eventBus__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/eventBus */ "./src/utils/eventBus.js");
/* harmony import */ var _utils_eventBus__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_utils_eventBus__WEBPACK_IMPORTED_MODULE_0__);
// TODO We have to renew timer every event
// TODO
var lockTime = 10 * 60 * 1000 * 6 * 100; // 100 hours

 // let lockTime = 60 * 1000 // 60 sec

console.log('Lock time: ' + lockTime / 1000 + ' sec.'); // let lockTime = 10 * 1000

var SALT = 'salt*/-+^';

function lockAccount() {
  var timer = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
  // LOCK > {lock: true}
  userStorage.lock.setLock(true); // if (userStorage.name === 'background') {
  //
  //     // Only publicKey and net left
  //     ENQWeb.Enq.User = { publicKey: ENQWeb.Enq.User.publicKey, net: ENQWeb.Enq.User.net }
  // }

  _utils_eventBus__WEBPACK_IMPORTED_MODULE_0___default().dispatch('lock', {
    message: true
  }); // {publicKey, net}

  ENQWeb.Enq.User = {
    publicKey: ENQWeb.Enq.User.publicKey,
    net: ENQWeb.Enq.User.net
  };
  var accountLockedString = 'Account locked';
  console.log(accountLockedString); // if (timer)
  //     location.reload()
} //


function encryptAccount() {
  var account = userStorage.user.loadUserNotJson(); // TODO HERE {}
  // console.log(account)

  var password = userStorage.lock.getHashPassword();

  if (password && !userStorage.lock.checkLock()) {
    password = ENQWeb.Utils.crypto.strengthenPassword(SALT + password);
    account = ENQWeb.Utils.crypto.encrypt(account, password);
    userStorage.user.changeUser(account);
    var accountEncryptedString = 'Account encrypted';
    console.log(accountEncryptedString);
  } else {
    if (!userStorage.lock.getHashPassword()) {
      var passwordString = 'Password not set';
      console.log(passwordString);
    }
  }
}

function encryptAccountWithPass(account, password) {
  if (password && !userStorage.lock.checkLock()) {
    password = ENQWeb.Utils.crypto.strengthenPassword(SALT + password);
    account = ENQWeb.Utils.crypto.encrypt(account, password);
    userStorage.user.changeUser(account); // console.log('account encrypted')
  }
}

function decryptAccount(password) {
  var hash = ENQWeb.Utils.crypto.strengthenPassword(SALT + password);

  if (userStorage.lock.unlock(hash)) {
    hash = ENQWeb.Utils.crypto.strengthenPassword(SALT + hash); // console.log(hash)
    // console.log(userStorage.user.loadUserNotJson())

    var userData = userStorage.user.loadUserNotJson();
    if (!userData) return false;
    var accountString = ENQWeb.Utils.crypto.decrypt(userData, hash); // console.log(accountString)

    var account = JSON.parse(accountString); // console.log(account)

    return account;
  } else {
    return false;
  }
}



function say() {
  var lockString = 'Lock account loaded. Background started';
  console.log(lockString);
}


})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianMvbG9ja0FjY291bnQuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUEsSUFBTUEsUUFBUSxHQUFHO0FBQ2JDLEVBQUFBLEVBRGEsY0FDVkMsS0FEVSxFQUNIQyxRQURHLEVBQ087QUFDaEJDLElBQUFBLFFBQVEsQ0FBQ0MsZ0JBQVQsQ0FBMEJILEtBQTFCLEVBQWlDLFVBQUNJLENBQUQ7QUFBQSxhQUFPSCxRQUFRLENBQUNHLENBQUMsQ0FBQ0MsTUFBSCxDQUFmO0FBQUEsS0FBakM7QUFDSCxHQUhZO0FBSWJDLEVBQUFBLFFBSmEsb0JBSUpOLEtBSkksRUFJR08sSUFKSCxFQUlTO0FBQ2xCTCxJQUFBQSxRQUFRLENBQUNNLGFBQVQsQ0FBdUIsSUFBSUMsV0FBSixDQUFnQlQsS0FBaEIsRUFBdUI7QUFBRUssTUFBQUEsTUFBTSxFQUFFRTtBQUFWLEtBQXZCLENBQXZCO0FBQ0gsR0FOWTtBQU9iRyxFQUFBQSxNQVBhLGtCQU9OVixLQVBNLEVBT0NDLFFBUEQsRUFPVztBQUNwQkMsSUFBQUEsUUFBUSxDQUFDUyxtQkFBVCxDQUE2QlgsS0FBN0IsRUFBb0NDLFFBQXBDO0FBQ0g7QUFUWSxDQUFqQjtBQVlBVyxNQUFNLENBQUNDLE9BQVAsR0FBaUJmLFFBQWpCOzs7Ozs7VUNaQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBOztVQUVBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBOzs7OztXQ3RCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsaUNBQWlDLFdBQVc7V0FDNUM7V0FDQTs7Ozs7V0NQQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLHlDQUF5Qyx3Q0FBd0M7V0FDakY7V0FDQTtXQUNBOzs7OztXQ1BBOzs7OztXQ0FBO1dBQ0E7V0FDQTtXQUNBLHVEQUF1RCxpQkFBaUI7V0FDeEU7V0FDQSxnREFBZ0QsYUFBYTtXQUM3RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ05BO0FBQ0E7QUFFQSxJQUFJZ0IsUUFBUSxHQUFHLEtBQUssRUFBTCxHQUFVLElBQVYsR0FBaUIsQ0FBakIsR0FBcUIsR0FBcEMsRUFBd0M7O0NBR3hDOztBQUVBQyxPQUFPLENBQUNDLEdBQVIsQ0FBWSxnQkFBaUJGLFFBQVEsR0FBRyxJQUE1QixHQUFvQyxPQUFoRCxHQUVBOztBQUVBLElBQUlHLElBQUksR0FBRyxXQUFYOztBQUVBLFNBQVNDLFdBQVQsR0FBb0M7QUFBQSxNQUFmQyxLQUFlLHVFQUFQLEtBQU87QUFFaEM7QUFDQUMsRUFBQUEsV0FBVyxDQUFDQyxJQUFaLENBQWlCQyxPQUFqQixDQUF5QixJQUF6QixFQUhnQyxDQUtoQztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBeEIsRUFBQUEsK0RBQUEsQ0FBa0IsTUFBbEIsRUFBMEI7QUFBQ3lCLElBQUFBLE9BQU8sRUFBRTtBQUFWLEdBQTFCLEVBWGdDLENBYWhDOztBQUNBQyxFQUFBQSxNQUFNLENBQUNDLEdBQVAsQ0FBV0MsSUFBWCxHQUFrQjtBQUFFQyxJQUFBQSxTQUFTLEVBQUVILE1BQU0sQ0FBQ0MsR0FBUCxDQUFXQyxJQUFYLENBQWdCQyxTQUE3QjtBQUF3Q0MsSUFBQUEsR0FBRyxFQUFFSixNQUFNLENBQUNDLEdBQVAsQ0FBV0MsSUFBWCxDQUFnQkU7QUFBN0QsR0FBbEI7QUFFQSxNQUFNQyxtQkFBbUIsR0FBRyxnQkFBNUI7QUFDQWQsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlhLG1CQUFaLEVBakJnQyxDQW1CaEM7QUFDQTtBQUNILEVBRUQ7OztBQUNBLFNBQVNDLGNBQVQsR0FBMEI7QUFFdEIsTUFBSUMsT0FBTyxHQUFHWCxXQUFXLENBQUNZLElBQVosQ0FBaUJDLGVBQWpCLEVBQWQsQ0FGc0IsQ0FJdEI7QUFDQTs7QUFFQSxNQUFJQyxRQUFRLEdBQUdkLFdBQVcsQ0FBQ0MsSUFBWixDQUFpQmMsZUFBakIsRUFBZjs7QUFDQSxNQUFJRCxRQUFRLElBQUksQ0FBQ2QsV0FBVyxDQUFDQyxJQUFaLENBQWlCZSxTQUFqQixFQUFqQixFQUErQztBQUUzQ0YsSUFBQUEsUUFBUSxHQUFHVixNQUFNLENBQUNhLEtBQVAsQ0FBYUMsTUFBYixDQUFvQkMsa0JBQXBCLENBQXVDdEIsSUFBSSxHQUFHaUIsUUFBOUMsQ0FBWDtBQUNBSCxJQUFBQSxPQUFPLEdBQUdQLE1BQU0sQ0FBQ2EsS0FBUCxDQUFhQyxNQUFiLENBQW9CRSxPQUFwQixDQUE0QlQsT0FBNUIsRUFBcUNHLFFBQXJDLENBQVY7QUFDQWQsSUFBQUEsV0FBVyxDQUFDWSxJQUFaLENBQWlCUyxVQUFqQixDQUE0QlYsT0FBNUI7QUFFQSxRQUFNVyxzQkFBc0IsR0FBRyxtQkFBL0I7QUFDQTNCLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZMEIsc0JBQVo7QUFFSCxHQVRELE1BU087QUFFSCxRQUFJLENBQUN0QixXQUFXLENBQUNDLElBQVosQ0FBaUJjLGVBQWpCLEVBQUwsRUFBeUM7QUFFckMsVUFBTVEsY0FBYyxHQUFHLGtCQUF2QjtBQUNBNUIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVkyQixjQUFaO0FBQ0g7QUFDSjtBQUNKOztBQUVELFNBQVNDLHNCQUFULENBQWdDYixPQUFoQyxFQUF5Q0csUUFBekMsRUFBbUQ7QUFDL0MsTUFBSUEsUUFBUSxJQUFJLENBQUNkLFdBQVcsQ0FBQ0MsSUFBWixDQUFpQmUsU0FBakIsRUFBakIsRUFBK0M7QUFDM0NGLElBQUFBLFFBQVEsR0FBR1YsTUFBTSxDQUFDYSxLQUFQLENBQWFDLE1BQWIsQ0FBb0JDLGtCQUFwQixDQUF1Q3RCLElBQUksR0FBR2lCLFFBQTlDLENBQVg7QUFDQUgsSUFBQUEsT0FBTyxHQUFHUCxNQUFNLENBQUNhLEtBQVAsQ0FBYUMsTUFBYixDQUFvQkUsT0FBcEIsQ0FBNEJULE9BQTVCLEVBQXFDRyxRQUFyQyxDQUFWO0FBQ0FkLElBQUFBLFdBQVcsQ0FBQ1ksSUFBWixDQUFpQlMsVUFBakIsQ0FBNEJWLE9BQTVCLEVBSDJDLENBSTNDO0FBQ0g7QUFDSjs7QUFFRCxTQUFTYyxjQUFULENBQXdCWCxRQUF4QixFQUFrQztBQUM5QixNQUFJWSxJQUFJLEdBQUd0QixNQUFNLENBQUNhLEtBQVAsQ0FBYUMsTUFBYixDQUFvQkMsa0JBQXBCLENBQXVDdEIsSUFBSSxHQUFHaUIsUUFBOUMsQ0FBWDs7QUFDQSxNQUFJZCxXQUFXLENBQUNDLElBQVosQ0FBaUIwQixNQUFqQixDQUF3QkQsSUFBeEIsQ0FBSixFQUFtQztBQUMvQkEsSUFBQUEsSUFBSSxHQUFHdEIsTUFBTSxDQUFDYSxLQUFQLENBQWFDLE1BQWIsQ0FBb0JDLGtCQUFwQixDQUF1Q3RCLElBQUksR0FBRzZCLElBQTlDLENBQVAsQ0FEK0IsQ0FFL0I7QUFDQTs7QUFDQSxRQUFJRSxRQUFRLEdBQUc1QixXQUFXLENBQUNZLElBQVosQ0FBaUJDLGVBQWpCLEVBQWY7QUFDQSxRQUFJLENBQUNlLFFBQUwsRUFDSSxPQUFPLEtBQVA7QUFDSixRQUFJQyxhQUFhLEdBQUd6QixNQUFNLENBQUNhLEtBQVAsQ0FBYUMsTUFBYixDQUFvQlksT0FBcEIsQ0FBNEJGLFFBQTVCLEVBQXNDRixJQUF0QyxDQUFwQixDQVArQixDQVEvQjs7QUFDQSxRQUFJZixPQUFPLEdBQUdvQixJQUFJLENBQUNDLEtBQUwsQ0FBV0gsYUFBWCxDQUFkLENBVCtCLENBVS9COztBQUNBLFdBQU9sQixPQUFQO0FBQ0gsR0FaRCxNQVlPO0FBQ0gsV0FBTyxLQUFQO0FBQ0g7QUFDSjs7QUFFRDs7QUFFQSxTQUFTc0IsR0FBVCxHQUFlO0FBQ1gsTUFBSUMsVUFBVSxHQUFHLHlDQUFqQjtBQUNBdkMsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlzQyxVQUFaO0FBQ0giLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9lbmVjdXVtLXdhbGxldC1leHRlbnNpb24vLi9zcmMvdXRpbHMvZXZlbnRCdXMuanMiLCJ3ZWJwYWNrOi8vZW5lY3V1bS13YWxsZXQtZXh0ZW5zaW9uL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL2VuZWN1dW0td2FsbGV0LWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvY29tcGF0IGdldCBkZWZhdWx0IGV4cG9ydCIsIndlYnBhY2s6Ly9lbmVjdXVtLXdhbGxldC1leHRlbnNpb24vd2VicGFjay9ydW50aW1lL2RlZmluZSBwcm9wZXJ0eSBnZXR0ZXJzIiwid2VicGFjazovL2VuZWN1dW0td2FsbGV0LWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL2VuZWN1dW0td2FsbGV0LWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovL2VuZWN1dW0td2FsbGV0LWV4dGVuc2lvbi8uL3NyYy9sb2NrQWNjb3VudC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBldmVudEJ1cyA9IHtcbiAgICBvbihldmVudCwgY2FsbGJhY2spIHtcbiAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihldmVudCwgKGUpID0+IGNhbGxiYWNrKGUuZGV0YWlsKSlcbiAgICB9LFxuICAgIGRpc3BhdGNoKGV2ZW50LCBkYXRhKSB7XG4gICAgICAgIGRvY3VtZW50LmRpc3BhdGNoRXZlbnQobmV3IEN1c3RvbUV2ZW50KGV2ZW50LCB7IGRldGFpbDogZGF0YSB9KSlcbiAgICB9LFxuICAgIHJlbW92ZShldmVudCwgY2FsbGJhY2spIHtcbiAgICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihldmVudCwgY2FsbGJhY2spXG4gICAgfSxcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBldmVudEJ1cyIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0obW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4iLCIvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuX193ZWJwYWNrX3JlcXVpcmVfXy5uID0gKG1vZHVsZSkgPT4ge1xuXHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cblx0XHQoKSA9PiAobW9kdWxlWydkZWZhdWx0J10pIDpcblx0XHQoKSA9PiAobW9kdWxlKTtcblx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgeyBhOiBnZXR0ZXIgfSk7XG5cdHJldHVybiBnZXR0ZXI7XG59OyIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCIvLyBUT0RPIFdlIGhhdmUgdG8gcmVuZXcgdGltZXIgZXZlcnkgZXZlbnRcbi8vIFRPRE9cblxubGV0IGxvY2tUaW1lID0gMTAgKiA2MCAqIDEwMDAgKiA2ICogMTAwIC8vIDEwMCBob3Vyc1xuaW1wb3J0IGV2ZW50QnVzIGZyb20gXCIuL3V0aWxzL2V2ZW50QnVzXCI7XG5cbi8vIGxldCBsb2NrVGltZSA9IDYwICogMTAwMCAvLyA2MCBzZWNcblxuY29uc29sZS5sb2coJ0xvY2sgdGltZTogJyArIChsb2NrVGltZSAvIDEwMDApICsgJyBzZWMuJylcblxuLy8gbGV0IGxvY2tUaW1lID0gMTAgKiAxMDAwXG5cbmxldCBTQUxUID0gJ3NhbHQqLy0rXidcblxuZnVuY3Rpb24gbG9ja0FjY291bnQodGltZXIgPSBmYWxzZSkge1xuXG4gICAgLy8gTE9DSyA+IHtsb2NrOiB0cnVlfVxuICAgIHVzZXJTdG9yYWdlLmxvY2suc2V0TG9jayh0cnVlKVxuXG4gICAgLy8gaWYgKHVzZXJTdG9yYWdlLm5hbWUgPT09ICdiYWNrZ3JvdW5kJykge1xuICAgIC8vXG4gICAgLy8gICAgIC8vIE9ubHkgcHVibGljS2V5IGFuZCBuZXQgbGVmdFxuICAgIC8vICAgICBFTlFXZWIuRW5xLlVzZXIgPSB7IHB1YmxpY0tleTogRU5RV2ViLkVucS5Vc2VyLnB1YmxpY0tleSwgbmV0OiBFTlFXZWIuRW5xLlVzZXIubmV0IH1cbiAgICAvLyB9XG5cbiAgICBldmVudEJ1cy5kaXNwYXRjaCgnbG9jaycsIHttZXNzYWdlOiB0cnVlfSlcblxuICAgIC8vIHtwdWJsaWNLZXksIG5ldH1cbiAgICBFTlFXZWIuRW5xLlVzZXIgPSB7IHB1YmxpY0tleTogRU5RV2ViLkVucS5Vc2VyLnB1YmxpY0tleSwgbmV0OiBFTlFXZWIuRW5xLlVzZXIubmV0IH1cblxuICAgIGNvbnN0IGFjY291bnRMb2NrZWRTdHJpbmcgPSAnQWNjb3VudCBsb2NrZWQnXG4gICAgY29uc29sZS5sb2coYWNjb3VudExvY2tlZFN0cmluZylcblxuICAgIC8vIGlmICh0aW1lcilcbiAgICAvLyAgICAgbG9jYXRpb24ucmVsb2FkKClcbn1cblxuLy9cbmZ1bmN0aW9uIGVuY3J5cHRBY2NvdW50KCkge1xuXG4gICAgbGV0IGFjY291bnQgPSB1c2VyU3RvcmFnZS51c2VyLmxvYWRVc2VyTm90SnNvbigpXG5cbiAgICAvLyBUT0RPIEhFUkUge31cbiAgICAvLyBjb25zb2xlLmxvZyhhY2NvdW50KVxuXG4gICAgbGV0IHBhc3N3b3JkID0gdXNlclN0b3JhZ2UubG9jay5nZXRIYXNoUGFzc3dvcmQoKVxuICAgIGlmIChwYXNzd29yZCAmJiAhdXNlclN0b3JhZ2UubG9jay5jaGVja0xvY2soKSkge1xuXG4gICAgICAgIHBhc3N3b3JkID0gRU5RV2ViLlV0aWxzLmNyeXB0by5zdHJlbmd0aGVuUGFzc3dvcmQoU0FMVCArIHBhc3N3b3JkKVxuICAgICAgICBhY2NvdW50ID0gRU5RV2ViLlV0aWxzLmNyeXB0by5lbmNyeXB0KGFjY291bnQsIHBhc3N3b3JkKVxuICAgICAgICB1c2VyU3RvcmFnZS51c2VyLmNoYW5nZVVzZXIoYWNjb3VudClcblxuICAgICAgICBjb25zdCBhY2NvdW50RW5jcnlwdGVkU3RyaW5nID0gJ0FjY291bnQgZW5jcnlwdGVkJ1xuICAgICAgICBjb25zb2xlLmxvZyhhY2NvdW50RW5jcnlwdGVkU3RyaW5nKVxuXG4gICAgfSBlbHNlIHtcblxuICAgICAgICBpZiAoIXVzZXJTdG9yYWdlLmxvY2suZ2V0SGFzaFBhc3N3b3JkKCkpIHtcblxuICAgICAgICAgICAgY29uc3QgcGFzc3dvcmRTdHJpbmcgPSAnUGFzc3dvcmQgbm90IHNldCdcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHBhc3N3b3JkU3RyaW5nKVxuICAgICAgICB9XG4gICAgfVxufVxuXG5mdW5jdGlvbiBlbmNyeXB0QWNjb3VudFdpdGhQYXNzKGFjY291bnQsIHBhc3N3b3JkKSB7XG4gICAgaWYgKHBhc3N3b3JkICYmICF1c2VyU3RvcmFnZS5sb2NrLmNoZWNrTG9jaygpKSB7XG4gICAgICAgIHBhc3N3b3JkID0gRU5RV2ViLlV0aWxzLmNyeXB0by5zdHJlbmd0aGVuUGFzc3dvcmQoU0FMVCArIHBhc3N3b3JkKVxuICAgICAgICBhY2NvdW50ID0gRU5RV2ViLlV0aWxzLmNyeXB0by5lbmNyeXB0KGFjY291bnQsIHBhc3N3b3JkKVxuICAgICAgICB1c2VyU3RvcmFnZS51c2VyLmNoYW5nZVVzZXIoYWNjb3VudClcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ2FjY291bnQgZW5jcnlwdGVkJylcbiAgICB9XG59XG5cbmZ1bmN0aW9uIGRlY3J5cHRBY2NvdW50KHBhc3N3b3JkKSB7XG4gICAgbGV0IGhhc2ggPSBFTlFXZWIuVXRpbHMuY3J5cHRvLnN0cmVuZ3RoZW5QYXNzd29yZChTQUxUICsgcGFzc3dvcmQpXG4gICAgaWYgKHVzZXJTdG9yYWdlLmxvY2sudW5sb2NrKGhhc2gpKSB7XG4gICAgICAgIGhhc2ggPSBFTlFXZWIuVXRpbHMuY3J5cHRvLnN0cmVuZ3RoZW5QYXNzd29yZChTQUxUICsgaGFzaClcbiAgICAgICAgLy8gY29uc29sZS5sb2coaGFzaClcbiAgICAgICAgLy8gY29uc29sZS5sb2codXNlclN0b3JhZ2UudXNlci5sb2FkVXNlck5vdEpzb24oKSlcbiAgICAgICAgbGV0IHVzZXJEYXRhID0gdXNlclN0b3JhZ2UudXNlci5sb2FkVXNlck5vdEpzb24oKVxuICAgICAgICBpZiAoIXVzZXJEYXRhKVxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICAgIGxldCBhY2NvdW50U3RyaW5nID0gRU5RV2ViLlV0aWxzLmNyeXB0by5kZWNyeXB0KHVzZXJEYXRhLCBoYXNoKVxuICAgICAgICAvLyBjb25zb2xlLmxvZyhhY2NvdW50U3RyaW5nKVxuICAgICAgICBsZXQgYWNjb3VudCA9IEpTT04ucGFyc2UoYWNjb3VudFN0cmluZylcbiAgICAgICAgLy8gY29uc29sZS5sb2coYWNjb3VudClcbiAgICAgICAgcmV0dXJuIGFjY291bnRcbiAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG59XG5cbmV4cG9ydCB7bG9ja0FjY291bnQsIGVuY3J5cHRBY2NvdW50LCBkZWNyeXB0QWNjb3VudCwgZW5jcnlwdEFjY291bnRXaXRoUGFzcywgbG9ja1RpbWV9XG5cbmZ1bmN0aW9uIHNheSgpIHtcbiAgICBsZXQgbG9ja1N0cmluZyA9ICdMb2NrIGFjY291bnQgbG9hZGVkLiBCYWNrZ3JvdW5kIHN0YXJ0ZWQnXG4gICAgY29uc29sZS5sb2cobG9ja1N0cmluZylcbn1cblxuZXhwb3J0IHtzYXl9XG4iXSwibmFtZXMiOlsiZXZlbnRCdXMiLCJvbiIsImV2ZW50IiwiY2FsbGJhY2siLCJkb2N1bWVudCIsImFkZEV2ZW50TGlzdGVuZXIiLCJlIiwiZGV0YWlsIiwiZGlzcGF0Y2giLCJkYXRhIiwiZGlzcGF0Y2hFdmVudCIsIkN1c3RvbUV2ZW50IiwicmVtb3ZlIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsIm1vZHVsZSIsImV4cG9ydHMiLCJsb2NrVGltZSIsImNvbnNvbGUiLCJsb2ciLCJTQUxUIiwibG9ja0FjY291bnQiLCJ0aW1lciIsInVzZXJTdG9yYWdlIiwibG9jayIsInNldExvY2siLCJtZXNzYWdlIiwiRU5RV2ViIiwiRW5xIiwiVXNlciIsInB1YmxpY0tleSIsIm5ldCIsImFjY291bnRMb2NrZWRTdHJpbmciLCJlbmNyeXB0QWNjb3VudCIsImFjY291bnQiLCJ1c2VyIiwibG9hZFVzZXJOb3RKc29uIiwicGFzc3dvcmQiLCJnZXRIYXNoUGFzc3dvcmQiLCJjaGVja0xvY2siLCJVdGlscyIsImNyeXB0byIsInN0cmVuZ3RoZW5QYXNzd29yZCIsImVuY3J5cHQiLCJjaGFuZ2VVc2VyIiwiYWNjb3VudEVuY3J5cHRlZFN0cmluZyIsInBhc3N3b3JkU3RyaW5nIiwiZW5jcnlwdEFjY291bnRXaXRoUGFzcyIsImRlY3J5cHRBY2NvdW50IiwiaGFzaCIsInVubG9jayIsInVzZXJEYXRhIiwiYWNjb3VudFN0cmluZyIsImRlY3J5cHQiLCJKU09OIiwicGFyc2UiLCJzYXkiLCJsb2NrU3RyaW5nIl0sInNvdXJjZVJvb3QiOiIifQ==